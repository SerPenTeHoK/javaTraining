//: object/E12_LeftToReader.java
/****************** Exercise 12 *****************
 * Find the code for the second version of
 * HelloDate.java, the simple comment-
 * documentation example. Execute Javadoc on the
 * file and view the results with your Web browser.
 ************************************************/
package object;

public class E12_LeftToReader {
  public static void main(String args[]) {
    System.out.println("Exercise left to reader");
  }
} ///:~
